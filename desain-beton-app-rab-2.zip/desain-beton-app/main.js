const {app,BrowserWindow,Menu}=require('electron');
function buat(){const w=new BrowserWindow({width:1100,height:800,title:'Concreta'});Menu.setApplicationMenu(null);w.loadFile('index.html')}
app.whenReady().then(buat);
app.on('window-all-closed',()=>app.quit());
