@echo off
call npm install
call npm run build
echo Selesai. File .exe ada di folder dist
pause
